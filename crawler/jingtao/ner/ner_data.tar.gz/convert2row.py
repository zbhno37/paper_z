import sys
import os

def convert(rawfile):
    fopen = open(rawfile)
    lines = fopen.readlines()
    word = ''
    label = ''
    tmp_word,tmp_label=[[],[]]
    for i,line in enumerate(lines):
        if line !='\n':
            arr = line.split(' ')
            try:
                tmp_word.append(arr[0])
                tmp_label.append(arr[1].strip())
            except Exception, e:
                print rawfile,i
                return 
        else:
            if len(tmp_word)!=len(tmp_label):
                print 'wrong number'
            else:
                word += ' '.join(tmp_word)+'\n'
                label += ' '.join(tmp_label)+'\n'
            tmp_word = []
            tmp_label = []
    with open('%s_word'%(rawfile),'w') as fwrite:
        fwrite.write(word)
    with open('%s_label'%(rawfile),'w') as ffwrite:
        ffwrite.write(label)
    print 'done'

if __name__=='__main__':
    base_dir = os.getcwd()
    convert('%s/ner_all.txt'%(base_dir))
    #for i in xrange(5):
    #    convert('%s/ner.txt_train_%d'%(base_dir,i))
    #    convert('%s/ner.txt_test_%d'%(base_dir,i))

        
