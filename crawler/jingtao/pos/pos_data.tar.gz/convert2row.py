import sys
import os

def convert(rawfile):
    fopen = open(rawfile)
    lines = fopen.readlines()
    word = ''
    label = ''
    tmp_word,tmp_label=[[],[]]
    for line in lines:
        if line !='\n':
            arr = line.split(' ')
            tmp_word.append(arr[0])
            tmp_label.append(arr[1].strip())
        else:
            if len(tmp_word)!=len(tmp_label):
                print 'wrong number'
            else:
                word += ' '.join(tmp_word)+'\n'
                label += ' '.join(tmp_label)+'\n'
            tmp_word = []
            tmp_label = []
    with open('%s_word'%(rawfile),'w') as fwrite:
        fwrite.write(word)
    with open('%s_label'%(rawfile),'w') as ffwrite:
        ffwrite.write(label)
    print 'done'

def con2stanfordpos(rawfile):
    lines = open(rawfile).readlines()
    rs = ''
    new_line = []
    for line in lines:
        if line != '\n':
            arr = line.split(' ')
            new_line.append('%s/%s'%(arr[0],arr[1].strip()))
        else:
            
            rs += ' '.join(new_line)+'\n'
            new_line = []
    with open('%s_stanford'%(rawfile),'w')as output:
        output.write(rs)
    print rawfile,'done'
            
if __name__=='__main__':
    base_dir = os.getcwd()
    #convert('%s/pos_all.txt'%(base_dir))
    for i in xrange(5):
        #convert('%s/pos.txt_train_%d'%(base_dir,i))
        #convert('%s/pos.txt_test_%d'%(base_dir,i))
        con2stanfordpos('%s/pos.txt_train_%d'%(base_dir,i))
        
